from flask import Flask, render_template, request, redirect
import os
import joblib
import pandas as pd
from werkzeug.utils import secure_filename

app = Flask(__name__)

# Config
UPLOAD_FOLDER = 'uploads'
ALLOWED_EXTENSIONS = {'csv'}
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

# Create upload folder if it doesn't exist
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

# Load model
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
model_path = os.path.join(BASE_DIR, "model.pkl")
model_metadata = joblib.load(model_path)
model = model_metadata["model"]
feature_names = model_metadata["features"]

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

# Home route
@app.route("/")
def home():
    return render_template("index.html")

# Prediction route
@app.route("/predict", methods=["POST"])
def predict():
    if 'csv_file' not in request.files:
        return "No file part in the request."

    file = request.files['csv_file']

    if file.filename == '':
        return "No selected file."

    if file and allowed_file(file.filename):
        filename = secure_filename(file.filename)
        filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
        file.save(filepath)

        # Read CSV
        input_df = pd.read_csv(filepath)

        # Validate columns
        if not all(col in input_df.columns for col in feature_names):
            return f"CSV must contain columns: {feature_names}"

        # Reorder and filter columns
        input_df = input_df[feature_names]

        # Predict
        predictions = model.predict(input_df)
        probabilities = model.predict_proba(input_df)

        results = []
        for i, (pred, proba) in enumerate(zip(predictions, probabilities), 1):
            confidence = proba[pred] * 100
            status = "Full" if pred == 1 else "Not Full"
            results.append({
                "id": i,
                "status": status,
                "confidence": f"{confidence:.2f}%"
            })

        return render_template("predictions.html", results=results)
    
    return "Invalid file type. Please upload a CSV file."

if __name__ == "__main__":
    app.run(debug=True)
