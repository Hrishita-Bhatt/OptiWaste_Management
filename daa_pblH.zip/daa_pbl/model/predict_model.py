import pandas as pd
from joblib import load

model = load('model/model.pkl')

def predict_fill_levels(file_path):
    df = pd.read_csv(file_path)
    predictions = model.predict(df)
    return predictions


