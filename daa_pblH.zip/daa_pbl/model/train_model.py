import pandas as pd
import joblib
from sklearn.ensemble import RandomForestClassifier

# Sample garbage bin data (simulated for prediction)
data = {
    'temperature': [30, 32, 28, 35, 33, 29, 36, 27],
    'humidity': [45, 50, 55, 60, 52, 48, 63, 44],
    'days_since_last_pickup': [1, 2, 3, 4, 2, 3, 5, 1],
    'is_full': [0, 0, 1, 1, 1, 0, 1, 0]  # 0 = Not full, 1 = Full
}

# Create a DataFrame
df = pd.DataFrame(data)

# Features and target
X = df[['temperature', 'humidity', 'days_since_last_pickup']]
y = df['is_full']

# Train a Random Forest model
model = RandomForestClassifier()
model.fit(X, y)

# Save the trained model as model.pkl
joblib.dump(model, 'model.pkl')  # This will save it in the model/ folder
print("✅ Model trained and saved as model.pkl")
