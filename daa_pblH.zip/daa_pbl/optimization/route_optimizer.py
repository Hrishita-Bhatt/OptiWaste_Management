import networkx as nx
import json

def load_graph_from_file(filename):
    with open(filename, 'r') as f:
        data = json.load(f)
    G = nx.Graph()
    for edge in data["edges"]:
        G.add_edge(edge["source"], edge["target"], weight=edge["weight"])
    return G

def dijkstra_route(graph, bin_locations):
    route = []
    visited = set()
    current = bin_locations[0]
    visited.add(current)
    route.append(current)

    while len(visited) < len(bin_locations):
        shortest = float('inf')
        next_node = None
        for node in bin_locations:
            if node not in visited:
                try:
                    length = nx.dijkstra_path_length(graph, current, node)
                    if length < shortest:
                        shortest = length
                        next_node = node
                except nx.NetworkXNoPath:
                    continue
        if next_node:
            route.append(next_node)
            visited.add(next_node)
            current = next_node
        else:
            break

    return route
