from flask import Flask, request, render_template
from model.predict_model import predict_fill_levels
from optimization.route_optimizer import load_graph_from_file, dijkstra_route
import os

app = Flask(__name__)
app.config['UPLOAD_FOLDER'] = 'uploads'

# Ensure upload folder exists
if not os.path.exists(app.config['UPLOAD_FOLDER']):
    os.makedirs(app.config['UPLOAD_FOLDER'])

@app.route('/')
def home():
    return render_template('index.html')  # You must have this file in /templates

@app.route('/predict', methods=['POST'])
def predict():
    if 'file' not in request.files:
        return "No file part in the request", 400

    file = request.files['file']
    if file.filename == '':
        return "No selected file", 400

    if file:
        filepath = os.path.join(app.config['UPLOAD_FOLDER'], file.filename)
        file.save(filepath)

        try:
            # Step 1: Predict bin fill levels
            predicted = predict_fill_levels(filepath)

            # Step 2: Extract full bins
            full_bins = [str(i) for i, status in enumerate(predicted) if status == 1]

            if not full_bins:
                return render_template('result.html', predictions=predicted, route=None, message="No bins are full.")

            # Step 3: Load area graph
            graph = load_graph_from_file('area_graph.json')  # Make sure this file exists

            # Step 4: Compute optimized route for full bins
            route = dijkstra_route(graph, full_bins)

            return render_template('result.html', predictions=predicted, route=route, message=None)

        except Exception as e:
            return f"Error during processing: {str(e)}", 500

if __name__ == "__main__":
    app.run(debug=True)
