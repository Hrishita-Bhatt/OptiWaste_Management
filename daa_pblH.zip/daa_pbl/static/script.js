document.getElementById("dataForm").addEventListener("submit", function (e) {
  e.preventDefault();

  const fileInput = document.getElementById("dataFile");
  const formData = new FormData();
  formData.append("file", fileInput.files[0]);

  fetch("/predict", {
    method: "POST",
    body: formData
  })
    .then(res => res.json())
    .then(data => {
      const predictionsEl = document.getElementById("predictions");
      predictionsEl.innerHTML = "";

      data.predictions.forEach(bin => {
        const li = document.createElement("li");
        li.textContent = `Bin ${bin.id}: ${bin.fill_level}%`;
        predictionsEl.appendChild(li);
      });

      // Draw simple mock map
      const map = document.getElementById("map");
      map.innerHTML = `Optimized Route: ${data.route.join(" → ")}`;
    });
});
